import DoctorPatientsMain from "../../layouts/doctor-dashboard/DoctorpatientsMain"

export default function DoctorPatients() {
    return(
        <>
         <DoctorPatientsMain />
        </>
    )
}