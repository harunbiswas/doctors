 import DoctorAppointmentMain from "../../layouts/doctor-dashboard/DoctorAppointmentMain"
 
 export default function DoctorAppointment() {

    return(
        <>
      <DoctorAppointmentMain />
        </>
    )
 }