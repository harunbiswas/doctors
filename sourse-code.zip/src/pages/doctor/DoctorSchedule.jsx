 import Schedule from "../../components/dashboard/Schedule";
 
 export default function DoctorSchedule() {
    return(
        <>
        <Schedule />
        </>
    )
 }