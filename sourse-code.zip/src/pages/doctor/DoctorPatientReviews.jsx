 import DoctorPatientReviewsMain from "../../layouts/doctor-dashboard/DoctorPatientReviewsMain"
 
 export default function DoctorPatientReviews() {
    return(
        <>
        
                       <DoctorPatientReviewsMain />

        </>
    )
 }