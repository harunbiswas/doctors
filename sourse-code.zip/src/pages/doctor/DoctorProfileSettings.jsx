import DoctorProfileSettingsMain from "../../layouts/doctor-dashboard/DoctorProfileSettingsMain"

export default function DoctorProfileSettings() {
    return(
        <>
        <DoctorProfileSettingsMain />
        </>
    )
}