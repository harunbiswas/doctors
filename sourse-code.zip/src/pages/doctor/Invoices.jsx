import InvoicesMain from "../../layouts/doctor-dashboard/InvoiceMain"

export default function Invoices() {
    return(
        <>
        <InvoicesMain />
        </>
    )
}