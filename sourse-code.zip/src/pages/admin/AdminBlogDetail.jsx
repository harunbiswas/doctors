import SingleBlogBody from "../../layouts/frontend/blog/SingleBlogBody";

export default function AdminBlogDetail(){
    return(
        <>
        <SingleBlogBody />
        </>
    )
}