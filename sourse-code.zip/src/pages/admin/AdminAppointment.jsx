import DoctorAppointmentMain from "../../layouts/doctor-dashboard/DoctorAppointmentMain";

export default function AdminAppointment(){
    return(
        <>
            <div className="pt-5 mt-5 m-2">
                <DoctorAppointmentMain />
            </div>
        </>
    )
}